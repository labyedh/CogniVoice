// frontend/services/api.ts (Corrected SSE Implementation)

import { AnalysisResult, LegacyAnalysisResult } from '../types';

const API_BASE_URL = import.meta.env.VITE_REACT_APP_API_URL || 'http://127.0.0.1:5000';

const recommendations = [
    'Consider consulting with a healthcare professional for further evaluation',
    'Regular cognitive exercises may be beneficial',
    'Maintain social engagement and mental stimulation'
  ];


export const analyzeAudio = async (
  audioFile: File | Blob, 
  onStepComplete?: (step: number) => void
): Promise<LegacyAnalysisResult> => {

  return new Promise((resolve, reject) => {
    const formData = new FormData();
    formData.append('audio', audioFile, audioFile instanceof File ? audioFile.name : 'recording.wav');

    const requestId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    formData.append('requestId', requestId);

    let eventSource: EventSource | null = null;
    let timeoutId: NodeJS.Timeout | null = null;
    
    // Setup timeout for the entire process (10 minutes)
    timeoutId = setTimeout(() => {
      eventSource?.close();
      reject(new Error('Analysis timeout. Please try again.'));
    }, 30 * 60 * 1000);

    // Setup EventSource for progress updates
    eventSource = new EventSource(`${API_BASE_URL}/progress/${requestId}`);

    eventSource.onopen = () => {
      console.log('SSE connection established');
    };

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle heartbeat messages
        if (data.heartbeat) {
          console.log("SSE Heartbeat received");
          return;
        }
        
        console.log('SSE Message received:', data);
    
        // Handle error in result
        if (data.result && data.result.error) {
          console.error('Backend error:', data.result.error);
          eventSource?.close();
          if (timeoutId) clearTimeout(timeoutId);
          reject(new Error(data.result.error));
          return;
        }
    
        // Handle progress updates
        if (data.step && !data.is_final) {
          onStepComplete?.(data.step);
          return;
        }
    
        // Handle final result
        if (data.is_final && data.result) {
          console.log('Final result received:', data.result);
          eventSource?.close();
          if (timeoutId) clearTimeout(timeoutId);
          let confidenceValue = data.result.confidence;
          if (data.result.finalPrediction === 'Control') {
            confidenceValue= 1 - data.result.confidence;
          }
          // Transform the result to match AnalysisResult interface
          const analysisResult: AnalysisResult = {
            fileName: data.result.fileName,
            finalPrediction: data.result.finalPrediction,
            confidence: confidenceValue,
            voteCounts: data.result.voteCounts,
            visualizationUrl: data.result.visualizationUrl,
            speechfeatures: {
              pauseFrequency: data.result.speechfeatures.pauseFrequency,
              speechRate: data.result.speechfeatures.speechRate,
              vocabularyComplexity: data.result.speechfeatures.vocabularyComplexity,
              semanticFluency: data.result.speechfeatures.semanticFluency
            }
          };
          
          let riskLevel: 'low' | 'moderate' | 'high';
          riskLevel = 'low'; // Default risk level
          if (data.result.finalPrediction === 'Dementia') {
            if (confidenceValue > 0.75) {
              riskLevel = 'high';
            } else if (confidenceValue >= 0.5) {
              riskLevel = 'moderate';
            } else {
              riskLevel = 'low';
            }
          }
          const legacyAnalysisResult: LegacyAnalysisResult = {
            id: `analysis_${Date.now()}`,
            riskLevel: riskLevel,
            recommendations: recommendations,
            timestamp: new Date().toISOString(),
            backendData: analysisResult
          
        }
          resolve(legacyAnalysisResult);
          return;
        }
    
      } catch (error) {
        console.error('Error parsing SSE message:', error);
      }
    };
    
    eventSource.onerror = (error) => {
      console.log('EventSource error:', error);
      eventSource?.close();
      if (timeoutId) clearTimeout(timeoutId);
      reject(new Error('Connection lost during analysis'));
    };
    
    fetch(`${API_BASE_URL}/predict`, {
      method: 'POST',
      body: formData,
    })
    .then(response => {
      if (!response.ok) {
        throw new Error(`Server responded with status ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      console.log('Analysis job started successfully');
    })
    .catch(error => {
      console.error('Error starting analysis:', error);
      eventSource?.close();
      if (timeoutId) clearTimeout(timeoutId);
      reject(error);
    });
  });
};


export const mockAnalyzeAudio = async (audioFile: File | Blob): Promise<LegacyAnalysisResult> => {
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  return {
    id: `analysis_${Date.now()}`,
    riskLevel: 'low',
    recommendations: recommendations,
    timestamp: new Date().toISOString(),
    backendData: {
      fileName: 'mock-audio.wav',
      finalPrediction: 'Healthy',
      confidence: 0.85,
      voteCounts: {
        Control: 8,
        Dementia: 2
      },
      visualizationUrl: '',
      speechfeatures: {
        pauseFrequency: 0.65,
        speechRate: 0.78,
        vocabularyComplexity: 0.82,
        semanticFluency: 0.75
      }
    }
  };
};