import React, { useState } from 'react';
import { Brain } from 'lucide-react';
import DashboardLayout from '../components/Layout/DashboardLayout';
import ImagePrompt from '../components/ImagePrompt';
import AudioRecorder from '../components/AudioRecorder';
import LoadingScreen from '../components/LoadingScreen';
import ResultsScreen from '../components/ResultsScreen';
import { AudioData, LegacyAnalysisResult } from '../types';
import { analyzeAudio } from '../services/api';

type AppState = 'recording' | 'loading' | 'results';

const AnalysisPage: React.FC = () => {
  const [currentState, setCurrentState] = useState<AppState>('recording');
  const [analysisResult, setAnalysisResult] = useState<LegacyAnalysisResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  // Sample image for the cognitive test
  const testImage = {
    url: 'Cookie-Theft-Picture-4_W640.jpg',
    alt: 'Cookie Theft Picture - Kitchen scene',
    description: 'Look at this kitchen scene carefully. Please describe everything you see happening in this picture, including the people, their actions, objects, and any details you notice. Take your time to observe all the elements in the image.'
  };

  const handleAudioReady = async (audioData: AudioData) => {
    if (!audioData.blob && !audioData.file) return;

    setIsProcessing(true);
    setCurrentState('loading');
    setLoadingStep(0);

    try {
      const audioToAnalyze = audioData.file || audioData.blob!;
      const result = await analyzeAudio(audioToAnalyze, (step) => {
        setLoadingStep(step);
      });
      setAnalysisResult(result);
      setCurrentState('results');
    } catch (error) {
      console.error('Analysis failed:', error);
      // Handle error - could show error state
      setCurrentState('recording');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleStartOver = () => {
    setCurrentState('recording');
    setAnalysisResult(null);
    setIsProcessing(false);
    setLoadingStep(0);
  };

  if (currentState === 'loading') {
    return <LoadingScreen message="Analyzing your speech for cognitive patterns..." currentStep={loadingStep} />;
  }

  if (currentState === 'results' && analysisResult) {
    return <ResultsScreen result={analysisResult} onStartOver={handleStartOver} />;
  }

  return (
    <DashboardLayout title="Cognitive Speech Analysis" subtitle="AI-powered early detection through speech pattern analysis">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Column - Image Prompt */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6 border border-[#FFEAD8]">
              <h2 className="text-xl font-semibold text-[#2A1458] mb-4">
                Step 1: View the Image
              </h2>
              <p className="text-gray-600 mb-6">
                Take a moment to carefully observe the image below. You'll be asked to describe what you see in detail.
              </p>
            </div>
            
            <ImagePrompt 
              imageUrl={testImage.url}
              alt={testImage.alt}
              description={testImage.description}
            />
          </div>

          {/* Right Column - Audio Recording */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-lg p-6 border border-[#FFEAD8]">
              <h2 className="text-xl font-semibold text-[#2A1458] mb-4">
                Step 2: Record Your Description
              </h2>
              <p className="text-gray-600 mb-6">
                Describe the image in as much detail as possible. Include what you see, 
                the activities taking place, emotions conveyed, and any stories the image tells you.
              </p>
              
              <div className="bg-gradient-to-r from-[#FFEAD8] to-[#E8988A]/20 border border-[#E8988A]/30 rounded-lg p-4 mb-6">
                <h4 className="font-semibold text-[#2A1458] mb-2">Tips for a good recording:</h4>
                <ul className="text-sm text-gray-700 space-y-1">
                  <li>• Speak clearly and at a natural pace</li>
                  <li>• Describe both obvious and subtle details</li>
                  <li>• Take your time - there's no rush</li>
                  <li>• Include your thoughts and interpretations</li>
                </ul>
              </div>
            </div>

            <AudioRecorder 
              onAudioReady={handleAudioReady}
              disabled={isProcessing}
            />
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-12 bg-white rounded-xl shadow-lg p-6 border border-[#FFEAD8]">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-[#2A1458] mb-2">
              How It Works
            </h3>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our AI analyzes various aspects of your speech including pause patterns, 
              vocabulary complexity, semantic fluency, and speech rate to identify potential 
              early indicators of cognitive changes. This tool is designed to complement, 
              not replace, professional medical evaluation.
            </p>
          </div>
        </div>
    </DashboardLayout>
  );
};

export default AnalysisPage;