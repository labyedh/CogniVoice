import React from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Users, Activity, TrendingUp, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import DashboardLayout from '../../components/Layout/DashboardLayout';
import { useAdmin } from '../../contexts/AdminContext';

const AdminDashboard: React.FC = () => {
  const { stats } = useAdmin();

  const riskData = [
    { name: 'Low Risk', value: stats.riskDistribution.low, color: '#10B981' },
    { name: 'Moderate Risk', value: stats.riskDistribution.moderate, color: '#F59E0B' },
    { name: 'High Risk', value: stats.riskDistribution.high, color: '#EF4444' }
  ];

  const statsCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: Users,
      color: 'from-[#9B177E] to-[#2A1458]',
      change: '+12%'
    },
    {
      title: 'Total Analyses',
      value: stats.totalAnalyses,
      icon: Activity,
      color: 'from-[#E8988A] to-[#9B177E]',
      change: '+8%'
    },
    {
      title: 'Low Risk Users',
      value: stats.riskDistribution.low,
      icon: CheckCircle,
      color: 'from-green-500 to-green-600',
      change: '+5%'
    },
    {
      title: 'High Risk Users',
      value: stats.riskDistribution.high,
      icon: AlertTriangle,
      color: 'from-red-500 to-red-600',
      change: '+2%'
    }
  ];

  return (
    <DashboardLayout title="Admin Dashboard" subtitle="Overview of system analytics and user data">
      <div className="space-y-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statsCards.map((card, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg p-6 border border-[#FFEAD8] hover:shadow-xl transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <div className={`bg-gradient-to-r ${card.color} rounded-full p-3`}>
                  <card.icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-green-600 text-sm font-medium">{card.change}</span>
              </div>
              <h3 className="text-2xl font-bold text-[#2A1458] mb-1">{card.value}</h3>
              <p className="text-gray-600 text-sm">{card.title}</p>
            </div>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Risk Distribution Pie Chart */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-[#FFEAD8]">
            <h3 className="text-xl font-semibold text-[#2A1458] mb-6">Risk Level Distribution</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {riskData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center space-x-6 mt-4">
              {riskData.map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                  <span className="text-sm text-gray-600">{item.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Usage Chart */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-[#FFEAD8]">
            <h3 className="text-xl font-semibold text-[#2A1458] mb-6">Daily Usage Trends</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={stats.dailyUsage}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="date" 
                    stroke="#666"
                    fontSize={12}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  />
                  <YAxis stroke="#666" fontSize={12} />
                  <Tooltip 
                    labelFormatter={(value) => new Date(value).toLocaleDateString()}
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #FFEAD8',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="analyses" 
                    stroke="#9B177E" 
                    strokeWidth={3}
                    dot={{ fill: '#9B177E', strokeWidth: 2, r: 4 }}
                    name="Analyses"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="users" 
                    stroke="#E8988A" 
                    strokeWidth={3}
                    dot={{ fill: '#E8988A', strokeWidth: 2, r: 4 }}
                    name="Active Users"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Audio Analysis Overview */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-[#FFEAD8]">
          <h3 className="text-xl font-semibold text-[#2A1458] mb-6">Audio Analysis Overview</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.dailyUsage}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="date" 
                  stroke="#666"
                  fontSize={12}
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis stroke="#666" fontSize={12} />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString()}
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #FFEAD8',
                    borderRadius: '8px'
                  }}
                />
                <Bar 
                  dataKey="analyses" 
                  fill="url(#colorGradient)"
                  radius={[4, 4, 0, 0]}
                />
                <defs>
                  <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#9B177E" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#2A1458" stopOpacity={0.8}/>
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-[#FFEAD8]">
          <h3 className="text-xl font-semibold text-[#2A1458] mb-6">Recent Activity</h3>
          <div className="space-y-4">
            {[
              { user: 'John Doe', action: 'completed analysis', time: '2 minutes ago', risk: 'low' },
              { user: 'Jane Smith', action: 'registered account', time: '15 minutes ago', risk: null },
              { user: 'Mike Johnson', action: 'completed analysis', time: '1 hour ago', risk: 'moderate' },
              { user: 'Sarah Wilson', action: 'completed analysis', time: '2 hours ago', risk: 'high' }
            ].map((activity, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gradient-to-r from-[#FFEAD8]/30 to-[#E8988A]/10 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="bg-gradient-to-r from-[#9B177E] to-[#2A1458] rounded-full p-2">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-[#2A1458]">{activity.user}</p>
                    <p className="text-sm text-gray-600">{activity.action}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  {activity.risk && (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      activity.risk === 'low' ? 'bg-green-100 text-green-700' :
                      activity.risk === 'moderate' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {activity.risk} risk
                    </span>
                  )}
                  <span className="text-sm text-gray-500">{activity.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default AdminDashboard;