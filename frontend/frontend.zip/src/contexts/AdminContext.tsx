import React, { createContext, useContext, useState, useEffect } from 'react';
import { AdminUser, Partner, DashboardStats, AdminContextType } from '../types/admin';

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalAnalyses: 0,
    riskDistribution: { low: 0, moderate: 0, high: 0 },
    dailyUsage: []
  });

  // Mock data initialization
  useEffect(() => {
    const mockUsers: AdminUser[] = [
      {
        id: '1',
        email: 'john.doe@example.com',
        firstName: 'John',
        lastName: 'Doe',
        role: 'user',
        createdAt: '2024-01-15T10:30:00Z',
        lastLogin: '2024-01-20T14:20:00Z',
        analysisCount: 5,
        riskLevel: 'low',
        isActive: true
      },
      {
        id: '2',
        email: 'jane.smith@example.com',
        firstName: 'Jane',
        lastName: 'Smith',
        role: 'user',
        createdAt: '2024-01-10T09:15:00Z',
        lastLogin: '2024-01-19T16:45:00Z',
        analysisCount: 3,
        riskLevel: 'moderate',
        isActive: true
      },
      {
        id: '3',
        email: 'admin@cognivoice.com',
        firstName: 'Admin',
        lastName: 'User',
        role: 'admin',
        createdAt: '2024-01-01T00:00:00Z',
        lastLogin: '2024-01-20T18:00:00Z',
        analysisCount: 0,
        isActive: true
      }
    ];

    const mockPartners: Partner[] = [
      {
        id: '1',
        name: 'Johns Hopkins Medicine',
        type: 'Medical Institution',
        description: 'Leading research collaboration in neurological assessment.',
        logo: 'https://images.pexels.com/photos/3845810/pexels-photo-3845810.jpeg?auto=compress&cs=tinysrgb&w=200',
        website: 'https://hopkinsmedicine.org',
        contactEmail: 'research@jhmi.edu',
        isActive: true,
        createdAt: '2024-01-01T00:00:00Z'
      },
      {
        id: '2',
        name: 'Stanford AI Lab',
        type: 'Research Institution',
        description: 'Advanced machine learning research and development.',
        logo: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=200',
        website: 'https://ai.stanford.edu',
        contactEmail: 'contact@ai.stanford.edu',
        isActive: true,
        createdAt: '2024-01-05T00:00:00Z'
      }
    ];

    const mockStats: DashboardStats = {
      totalUsers: mockUsers.filter(u => u.role === 'user').length,
      totalAnalyses: mockUsers.reduce((sum, user) => sum + user.analysisCount, 0),
      riskDistribution: {
        low: mockUsers.filter(u => u.riskLevel === 'low').length,
        moderate: mockUsers.filter(u => u.riskLevel === 'moderate').length,
        high: mockUsers.filter(u => u.riskLevel === 'high').length
      },
      dailyUsage: [
        { date: '2024-01-15', analyses: 12, users: 8 },
        { date: '2024-01-16', analyses: 15, users: 10 },
        { date: '2024-01-17', analyses: 18, users: 12 },
        { date: '2024-01-18', analyses: 22, users: 15 },
        { date: '2024-01-19', analyses: 25, users: 18 },
        { date: '2024-01-20', analyses: 30, users: 20 }
      ]
    };

    setUsers(mockUsers);
    setPartners(mockPartners);
    setStats(mockStats);
  }, []);

  const createUser = async (userData: Omit<AdminUser, 'id' | 'createdAt'>) => {
    const newUser: AdminUser = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setUsers(prev => [...prev, newUser]);
  };

  const updateUser = async (id: string, userData: Partial<AdminUser>) => {
    setUsers(prev => prev.map(user => 
      user.id === id ? { ...user, ...userData } : user
    ));
  };

  const deleteUser = async (id: string) => {
    setUsers(prev => prev.filter(user => user.id !== id));
  };

  const createPartner = async (partnerData: Omit<Partner, 'id' | 'createdAt'>) => {
    const newPartner: Partner = {
      ...partnerData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    setPartners(prev => [...prev, newPartner]);
  };

  const updatePartner = async (id: string, partnerData: Partial<Partner>) => {
    setPartners(prev => prev.map(partner => 
      partner.id === id ? { ...partner, ...partnerData } : partner
    ));
  };

  const deletePartner = async (id: string) => {
    setPartners(prev => prev.filter(partner => partner.id !== id));
  };

  const refreshStats = async () => {
    // Recalculate stats based on current data
    const userCount = users.filter(u => u.role === 'user').length;
    const analysisCount = users.reduce((sum, user) => sum + user.analysisCount, 0);
    
    setStats(prev => ({
      ...prev,
      totalUsers: userCount,
      totalAnalyses: analysisCount,
      riskDistribution: {
        low: users.filter(u => u.riskLevel === 'low').length,
        moderate: users.filter(u => u.riskLevel === 'moderate').length,
        high: users.filter(u => u.riskLevel === 'high').length
      }
    }));
  };

  const value: AdminContextType = {
    users,
    partners,
    stats,
    createUser,
    updateUser,
    deleteUser,
    createPartner,
    updatePartner,
    deletePartner,
    refreshStats
  };

  return <AdminContext.Provider value={value}>{children}</AdminContext.Provider>;
};